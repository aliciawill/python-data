# Bear Face Detection and Hipsterizer

![](imgs/result.png)

![](imgs/result_hipsters.png)

- Bear face detection 
- Bear facial landmarks detection
- Bear hipsterizer (put glasses on)

## Dependancy

- Python 3
- dlib
- OpenCV
- matplotlib
- numpy
- imutils
